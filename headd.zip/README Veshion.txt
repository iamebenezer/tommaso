Veshion - A Font by Aluyeah Studio

Please read this before using the font.

You may use this version of 'Veshion' for personal use only.  If you wish to use it commercially you will need to purchase a license. Click here 

https://fontbundles.net/aluyeahstudio/404279-al-veshion
https://www.creativefabrica.com/product/veshion/

You mey like our other product

https://fontbundles.net/aluyeahstudio
https://www.myfonts.com/foundry/aluyeah-studio/
https://www.creativefabrica.com/designer/aluyeah-studio/

Any Question, you can submit your question here

https://www.behance.net/aluyeahstudio

PLEASE FOLLOW & APPRECIATE OUR PROJECT, Uyeah Mamen! 
